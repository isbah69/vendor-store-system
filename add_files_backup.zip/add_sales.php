<?php
session_start();
include_once "connection.php";

$last_sale_id = $_SESSION['last_sale_id'] ?? 0;
$sale_success = $_SESSION['sale_success'] ?? null;
$sale_error   = $_SESSION['sale_error'] ?? null;

unset($_SESSION['sale_success'], $_SESSION['sale_error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add New Sale</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>

body { background: #f5f7fa; padding: 20px; }
.card { border-radius: 10px; }
#search_product { height:48px; font-size:16px; }
.search-results { position:absolute; top:100%; left:0; right:0; background:#fff; border:1px solid #ddd; max-height:220px; overflow-y:auto; display:none; z-index:9999; }
.search-results div { padding:8px; cursor:pointer; }
.search-results div:hover { background:#f0f0f0; }
.table thead { background-color: #007bff; color: black; }
.float-end { float:right; }
.position-relative { position: relative; }

/* --- CSS for Walk-in Customer Bar --- */
.action-bar-container {
    display: flex;
    align-items: center; /* Vertically centers the content */
    border: 1px solid #ddd;
    background-color: #fff; /* White background for the bar itself */
    border-radius: 4px;
    margin-bottom: 20px; /* Space below the bar */
    /* To align the width with the col-md-3 search card */
    width: calc((100% / 12) * 3 - 30px); /* Adjusting for padding/margin of container/row */
    max-width: 100%; /* Ensures it fits within its container */
}

/* Wrapper for the select/input field */
.customer-select-wrapper {
    flex-grow: 1;
    padding: 0 5px 0 10px; /* Padding inside the bar for the text */
}

/* Styling the actual select element */
.customer-select {
    font-size: 16px;
    border: none;
    background: transparent;
    padding: 10px 0;
    width: 100%;
    height: 48px; /* Match the height of your search input */
    font-weight: 500;
    cursor: pointer;
}

/* Icon Buttons Container */
.icon-buttons {
    display: flex;
    height: 100%; /* Ensure buttons stretch vertically */
    border-left: 1px solid #ddd; /* Separator line between select and icons */
}

/* General button styling */
.icon-btn {
    border: none;
    background-color: transparent;
    cursor: pointer;
    padding: 12px 12px;
    font-size: 16px; 
    color: #007bff; /* Blue color for the icons */
    transition: background-color 0.1s;
    height: 48px; /* Set height to match the input */
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #eee; /* Separator between icon buttons */
}

.icon-btn:first-child {
    border-left: none; /* Remove separator on the first icon button */
}

.icon-btn:hover {
    background-color: #f0f0f0;
}

/* Specific styling for the 'Add' button (Blue background from your image) */
.icon-btn.add-btn {
    background-color: #007bff; /* Primary Bootstrap Blue */
    color: white;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
    border-left: none; /* The blue background makes the light separator unnecessary */
}

.icon-btn.add-btn:hover {
    background-color: #0056b3;
}

body { background: #f5f7fa; padding: 20px; }
.card { border-radius: 10px; }
#search_product { height:48px; font-size:16px; }
.search-results { position:absolute; top:100%; left:0; right:0; background:#fff; border:1px solid #ddd; max-height:220px; overflow-y:auto; display:none; z-index:9999; }
.search-results div { padding:8px; cursor:pointer; }
.search-results div:hover { background:#f0f0f0; }
.table thead { background-color: #007bff; color: black; }
.float-end { float:right; }
.position-relative { position: relative; }

</style>
</head>
<body>

<div class="container-fluid">
<h2 class="mb-4">🛍️ Add New Sale</h2>
<!-- Back Button -->
<a href="sales.php" class="btn btn-outline-primary mb-3">
  <i class="fa fa-arrow-left"></i> Back to Sales
</a>

<?php if (!empty($errorMsg)): ?>
  <div class="alert alert-danger"><?php echo htmlspecialchars($errorMsg); ?></div>
<?php endif; ?>

<!-- WALK-IN CUSTOMER BAR: same width as search card -->
<!-- WALK-IN CUSTOMER SECTION -->
 <input type="hidden" id="customer_id" name="customer_id" value="">

<div class="action-bar-container position-relative" style="width: calc((100% / 12) * 3 - 30px); max-width: 100%;">
    <div class="customer-select-wrapper position-relative" style="width:100%;">
        <input type="text" id="walkin_customer_search" class="form-control" placeholder="Search Walkin customer..." autocomplete="off">
        <input type="hidden" id="customer_id" name="customer_id">
        <div id="customer_suggestions" class="search-results" style="display:none; position:absolute; top:100%; left:0; right:0; background:white; border:1px solid #ddd; z-index:1000; max-height:200px; overflow-y:auto;"></div>
    </div>

    <div class="icon-buttons">
        <button class="icon-btn" id="editCustomerBtn">
            <i class="fas fa-pencil-alt"></i>
        </button>
        <!-- Eye Button (update to include id so JS targets the right button) -->
<button type="button" class="icon-btn" id="viewCustomerBtn" data-toggle="modal" data-target="#customerModal">
  <i class="fas fa-eye"></i>
</button>
<a href="add_customer.php" class="icon-btn" title="Add Customer">
  <i class="fa fa-plus"></i>
</a>


<!-- ==================== WALK-IN CUSTOMER MODAL (REPLACE YOUR OLD ONE) ==================== -->
<div id="customerModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="customerModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">WALK-IN CUSTOMER</h4>
        <button type="button" class="btn btn-default btn-sm pull-right" id="printCustomer">
          <i class="fa fa-print"></i> Print
        </button>
      </div>

      <!-- Modal Body (cells have ids so JS can fill them) -->
      <div class="modal-body" id="customerInfo">
        <table class="table table-bordered">
          <tr><th>Company</th><td id="c_company">Walk-in Customer</td></tr>
          <tr><th>Name</th><td id="c_name">Walk-in Customer</td></tr>
          <tr><th>Customer Group</th><td id="c_group">General</td></tr>
          <tr><th>VAT Number</th><td id="c_vat"></td></tr>
          <tr><th>GST Number</th><td id="c_gst"></td></tr>
          <tr><th>Deposit</th><td id="c_deposit">0.00</td></tr>
          <tr><th>Award Points</th><td id="c_points">0</td></tr>
          <tr><th>Email</th><td id="c_email">customer@tecdiary.com</td></tr>
          <tr><th>Phone</th><td id="c_phone">0123456789</td></tr>
          <tr><th>Address</th><td id="c_address">Customer Address</td></tr>
          <tr><th>City</th><td id="c_city">Khanpur</td></tr>
          <tr><th>State</th><td id="c_state">Punjab</td></tr>
          <tr><th>Postal Code</th><td id="c_postal">46000</td></tr>
          <tr><th>Country</th><td id="c_country">Pakistan</td></tr>
        </table>
      </div>

      <!-- Modal Footer -->
      <div class="modal-footer" style="display: flex; justify-content: space-between;">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
          <i class="fa fa-times"></i> Close
        </button>

        <div>
          <a href="customer_report.php?id=0" class="btn btn-info" id="customerReportBtn">
            <i class="fa fa-file-text-o"></i> Customer Report
          </a>
         <a href="exit_customer.php" class="btn btn-danger">
  <i class="fa fa-sign-out"></i> Exit Customer
</a>


        </div>
      </div>

    </div>
  </div>
</div>

<!-- PRINT handler (keeps your print behavior) -->
<script>
document.getElementById('printCustomer').addEventListener('click', function() {
  var printContents = document.getElementById('customerInfo').innerHTML;
  var printWindow = window.open('', '', 'width=800,height=600');
  printWindow.document.write('<html><head><title>Customer Info</title>');
  printWindow.document.write('<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">');
  printWindow.document.write('</head><body>');
  printWindow.document.write('<h3 style="text-align:center;">Customer Information</h3>');
  printWindow.document.write(printContents);
  printWindow.document.write('</body></html>');
  printWindow.document.close();
  printWindow.print();
});
</script>

<!-- Core JS: set selected customer id from search results AND load details into modal -->
<script>
/*
  Instructions:
  - Ensure jQuery is already loaded on your page (your page already includes it).
  - Ensure when a search result is clicked it has class "customer-item" and data-id attribute.
    (If your search_customer.php already outputs elements with class "customer-item" and data-id,
     the code below will automatically set the hidden input.)
  - This script:
      * sets #customer_id when a .customer-item is clicked
      * when you click the Eye button it fetches details for #customer_id and fills the modal
*/

// 1) When user clicks a search result, set the hidden customer_id and place name in search input.
//    This uses delegated event so it works with AJAX-inserted results.
$(document).on('click', '.customer-item', function(e) {
  e.preventDefault();
  var id = $(this).data('id') || $(this).attr('data-id');
  var name = $(this).data('name') || $(this).attr('data-name') || $(this).text().trim();
  // set hidden input
  $('#customer_id').val(id);
  // if you have an input showing selected customer name, set it too (common id used earlier)
  if ($('#walkin_customer_search').length) {
    $('#walkin_customer_search').val(name);
  } else if ($('#walkin_customer').length) {
    $('#walkin_customer').val(name);
  }
  // hide results dropdown if present
  $('#customer_suggestions, #customerResults, #customer_results, #customerSearchResults').hide();
});

// 2) When Eye button clicked (user opens modal), fetch selected customer details and fill table
$('#viewCustomerBtn').on('click', function() {
  var customerId = $('#customer_id').val() || '';
  if (!customerId || customerId === '0') {
    // no selected customer -> keep modal defaults (Walk-in) and ensure report link is id=0
    $('#customerReportBtn').attr('href','customer_report.php?id=0');
    return;
  }

  // fetch JSON from backend
  $.ajax({
    url: 'get_customer_details.php',
    method: 'GET',
    data: { id: customerId },
    dataType: 'json',
    success: function(res) {
      if (!res || res.status !== 'success') {
        console.warn('Customer not found or invalid response', res);
        // optionally show a message or reset to defaults
        $('#c_name').text('Walk-in Customer');
        $('#customerReportBtn').attr('href','customer_report.php?id=0');
        return;
      }

      // fill modal cells. use fallback empty string if key missing
      $('#c_company').text(res.company || 'Walk-in Customer');
      $('#c_name').text(res.name || '');
      $('#c_group').text(res.customer_group || 'General');
      $('#c_vat').text(res.vat_number || '');
      $('#c_gst').text(res.gst_number || '');
      $('#c_deposit').text(res.deposit || '0.00');
      $('#c_points').text(res.award_points || '0');
      $('#c_email').text(res.email || '');
      $('#c_phone').text(res.phone || '');
      $('#c_address').text(res.address || '');
      $('#c_city').text(res.city || '');
      $('#c_state').text(res.state || '');
      $('#c_postal').text(res.postal_code || '');
      $('#c_country').text(res.country || '');

      // update report link to selected customer
      $('#customerReportBtn').attr('href','customer_report.php?id=' + customerId);
    },
    error: function(xhr, status, err) {
      console.error('AJAX error', err);
    }
  });
});
</script>

      </div>
    </div>
  </div>
</div>

<!-- ==================== PRINT FUNCTION ==================== -->
<script>
  document.getElementById('printCustomer').addEventListener('click', function() {
    var printContents = document.getElementById('customerInfo').innerHTML;
    var printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write('<html><head><title>Customer Info</title>');
    printWindow.document.write('<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h3 style="text-align:center;">Customer Information</h3>');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
  });
</script>
    </div>
</div>
        
    </div>
</div>

<!-- CUSTOMER INFO MODAL -->
<div class="modal fade" id="customerModal" tabindex="-1" aria-labelledby="customerModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Customer Information</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="customer_details">
        <p class="text-muted">Select a customer to view details.</p>
      </div>
    </div>
  </div>
</div>

        


    
<!-- MAIN ROW: Left search/table + Right form -->
<div class="row">
  <!-- LEFT SIDE: Search + Product Table -->
  <div class="col-md-3">
    <div class="card shadow p-4 mb-4 position-relative">
      
      <input type="text" id="search_product" class="form-control" placeholder="Search product by name...">
      <div class="search-results" id="product_results"></div>
    </div>

    <div class="card shadow p-4">
      <div class="table-responsive">
        <table class="table table-bordered mt-3" id="selected_products">
          <thead>
            <tr>
              <th>Product</th>
              <th>Price</th>
              <th>Qty</th>
              <th>Subtotal</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- RIGHT SIDE: Sale Form -->
  <div class="col-md-9">
    <div class="card shadow p-3">
      <form action="save_sale.php" method="POST" id="saleForm">
        <div class="mb-3">
          <label class="fw-bold">Company Name</label>
          <select name="company_id" class="form-control" required>
            <option value="">-- Select Company --</option>
            <?php
            $companies = mysqli_query($con, "SELECT * FROM companies");
            while ($c = mysqli_fetch_assoc($companies)) {
              echo "<option value='".htmlspecialchars($c['company_id'])."'>".htmlspecialchars($c['name'])."</option>";
            }
            ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="fw-bold">Sale Date</label>
          <input type="date" name="sale_date" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
        </div>

        <div class="mb-3">
          <label class="fw-bold">Total Amount</label>
          <input type="text" id="total_amount" name="total_amount" class="form-control text-end" readonly value="0.00">
        </div>

        <div class="d-flex justify-content-between">
          <button type="submit" class="btn btn-primary px-4"><i class="fas fa-plus-circle"></i> Add Sale</button>
          <button type="reset" class="btn btn-secondary px-4"><i class="fas fa-undo"></i> Reset</button>
        </div>
      </form>
    </div>
  </div>
  <!-- ====================== -->
<!-- STOCK UPDATE SCRIPT -->
<!-- ====================== -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function updateProductStock(product_id, qty) {
  return $.ajax({
    url: 'update_stock.php',
    type: 'POST',
    data: { product_id: product_id, qty: qty }
  });
}

// 🟡 Attach submit event to the form
$('#saleForm').on('submit', function(e) {
  e.preventDefault(); // stop default submit first

  let ajaxCalls = [];
  let hasError = false;

  // Loop through products and update stock
  $('#selected_products tbody tr').each(function() {
    let product_id = $(this).find('input[name="product_id[]"]').val();
    let qty = $(this).find('input[name="qty[]"]').val();

    ajaxCalls.push(
      updateProductStock(product_id, qty).done(function(response) {
        if (response !== 'success') {
          hasError = true;
          if (response === 'not_enough_stock') {
            alert('⚠️ Not enough stock for product ID: ' + product_id);
          } else if (response === 'product_not_found') {
            alert('❌ Product not found: ' + product_id);
          } else {
            alert('❌ Failed to update stock for product ID: ' + product_id);
          }
        }
      })
    );
  });

  // When all stock updates are done, submit form if no errors
  $.when.apply($, ajaxCalls).done(function() {
    if (!hasError) {
      $('#saleForm').off('submit').submit(); // re-submit normally
    }
  });
});
</script>

</div> <!-- END ROW -->

<!-- SUMMARY + BUTTONS: full-width at bottom -->
 <div class="bg-white p-3 shadow">
<div class="container-fluid mt-3">
  <div class="card shadow p-3" style="max-width:25%; width:100%;">
    <table class="table table-borderless" style="width:100%; font-weight:bold; table-layout: fixed;">
      <tbody>
        <tr>
          <td>Items</td><td id="summary_items">0 (0)</td>
          <td>Total</td><td id="summary_total">₨ 0.00</td>
        </tr>
        <tr>
          <td style="position: relative;">
            Order Tax
            <i class="fa fa-pencil text-primary ms-1" style="cursor:pointer;" id="edit_tax"></i>
            <span id="summary_tax_display" class="float-end">₨ 0.00</span>

            <div id="tax_form" style="display:none; position: absolute; top: 25px; left: 0; background: white; border: 1px solid #ccc; padding: 8px; z-index: 1000; border-radius: 5px; min-width: 140px;">
              <select id="order_tax" class="form-control form-control-sm">
                <option value="0">No Tax</option>
                <option value="5">VAT @5%</option>
                <option value="10">VAT @10%</option>
                <option value="20">VAT @20%</option>
                <option value="17">sales @17%</option>
              </select>
              <button type="button" id="save_tax" class="btn btn-sm btn-primary mt-2 w-100">Save</button>
            </div>
          </td>

          <td>Discount <i class="fa fa-pencil text-primary ms-1" style="cursor:pointer;" id="edit_discount"></i></td>
          <td id="summary_discount_display">₨ 0.00</td>
        </tr>
      </tbody>
    </table>

    <div id="discount_form" style="display:none; margin-top:8px; position:relative;">
      <input type="number" id="discount_input" class="form-control mb-2" placeholder="Enter discount amount" min="0" step="0.01">
      <button type="button" class="btn btn-sm btn-success" id="save_discount">Save Discount</button>
    </div>

    <div class="mt-2" style="background:#e0e0e0; color:black; font-weight:bold; padding:8px; font-size:16px; display:flex; justify-content:space-between; align-items:center;">
      <span>Total Payable</span>
      <span>₨ <span id="total_payable">0.00</span></span>
    </div>

    <!-- Buttons -->
    <div class="mt-3">
      <button class="btn btn-warning" onclick="openSuspendModal()">Suspend</button>
      
 <button type="button" class="btn btn-success" id="billBtn">
  <i class="fas fa-file-invoice"></i> Bill
</button>

<script>
document.addEventListener('DOMContentLoaded', function () {

  const billBtn = document.getElementById('billBtn');
  billBtn.addEventListener('click', function () {

    let products = [];
    let subtotal = 0;
    let totalDiscount = 0;
    let totalTax = 0;

    // Get order-level tax & discount values
    let orderTaxPercent = parseFloat(document.getElementById('order_tax')?.value) || 0;
    let orderDiscountAmount = parseFloat(document.getElementById('discount_input')?.value) || 0;

    // Loop through selected products table
    document.querySelectorAll('#selected_products tbody tr').forEach(function (row) {
      let name = row.querySelector('td:nth-child(1)')?.innerText || '';
      let price = parseFloat(row.querySelector('input[name="price[]"]')?.value) || 0;
      let qty = parseInt(row.querySelector('input[name="qty[]"]')?.value) || 0;
      let discount = parseFloat(row.querySelector('input[name="discount[]"]')?.value) || 0; // per-item %
      let tax = parseFloat(row.querySelector('input[name="tax[]"]')?.value) || 0; // per-item %

      let lineTotal = price * qty;
      let discountAmount = (discount / 100) * lineTotal;
      let afterDiscount = lineTotal - discountAmount;
      let taxAmount = (tax / 100) * afterDiscount;
      let finalTotal = afterDiscount + taxAmount;

      subtotal += lineTotal;
      totalDiscount += discountAmount;
      totalTax += taxAmount;

      products.push({ name, price, qty, discount, tax, finalTotal });
    });

    if (products.length === 0) {
      alert('⚠️ No products added to generate bill!');
      return;
    }

    // Apply order-level discount
    totalDiscount += orderDiscountAmount;

    // Apply order-level tax on subtotal after discount
    let orderLevelTaxAmount = ((subtotal - totalDiscount) * orderTaxPercent) / 100;
    totalTax += orderLevelTaxAmount;

    let grandTotal = subtotal - totalDiscount + totalTax;

    // Open bill window
    let billWindow = window.open('', '_blank');
    billWindow.document.write(`
      <html>
      <head>
        <title>Bill</title>
        <style>
          body { font-family: Arial; font-size: 12px; padding: 10px; }
          h2, h3 { text-align: center; margin: 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          th, td { padding: 5px; text-align: left; border-bottom: 1px solid #ccc; }
          th { border-bottom: 2px solid #000; }
          tfoot td { font-weight: bold; }
          .total { text-align: right; }
        </style>
      </head>
      <body>
        <h2>Stock Manager Advance</h2>
        <h3>Bill</h3>
        <p><strong>C:</strong> Walk-in Customer</p>
        <p><strong>R:</strong> Owner</p>
        <p><strong>T:</strong> ${new Date().toLocaleString()}</p>

        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Item</th>
              <th>Qty</th>
              <th>Price</th>
              <th class="total">Total</th>
            </tr>
          </thead>
          <tbody>
    `);

    products.forEach((p, i) => {
      billWindow.document.write(`
        <tr>
          <td>${i + 1}</td>
          <td>${p.name}</td>
          <td>${p.qty}</td>
          <td>${p.price.toFixed(2)}</td>
          <td>${p.discount}</td>
          <td>${p.tax}</td>
          <td class="total">${p.finalTotal.toFixed(2)}</td>
        </tr>
      `);
    });

    billWindow.document.write(`
          </tbody>
          <tfoot>
            <tr>
              <td colspan="6">Subtotal</td>
              <td class="total">${subtotal.toFixed(2)}</td>
            </tr>
            <tr>
              <td colspan="6">Total Discount</td>
              <td class="total">- ${totalDiscount.toFixed(2)}</td>
            </tr>
            <tr>
              <td colspan="6">Total Tax</td>
              <td class="total">+ ${totalTax.toFixed(2)}</td>
            </tr>
            <tr>
              <td colspan="6">Grand Total</td>
              <td class="total"><strong>${grandTotal.toFixed(2)}</strong></td>
            </tr>
          </tfoot>
        </table>

        <p style="text-align:center;">Items: ${products.length} | Grand Total: ${grandTotal.toFixed(2)}</p>
        <p style="text-align:center;">Merchant Copy</p>

        <script>
          window.print();
        <\/script>
      </body>
      </html>
    `);
    billWindow.document.close();

  });

});
</script>




      <!-- 🛒 Order Button -->
<button type="button" id="orderBtn" 
  style="background-color:#6f42c1; border:none; color:white; padding:8px 14px; border-radius:5px;">
  <i class="fa fa-shopping-cart"></i> Order
</button>
<script>
  document.getElementById('orderBtn').addEventListener('click', function () {
    let products = [];
    let totalAmount = 0;

    // 🛍️ Loop through selected products table
    document.querySelectorAll('#selected_products tbody tr').forEach(function (row) {
      let name = row.querySelector('td:nth-child(1)').innerText;
      let price = parseFloat(row.querySelector('input[name="price[]"]').value);
      let qty = parseInt(row.querySelector('input[name="qty[]"]').value);
      let lineTotal = price * qty;
      totalAmount += lineTotal;

      products.push({ name, price, qty, lineTotal });
    });

    if (products.length === 0) {
      alert('⚠️ No products added to place an order!');
      return;
    }

    // 🧾 Create a new window for the order bill
    let orderWindow = window.open('', '_blank');
    orderWindow.document.write(`
      <html>
      <head>
        <title>Order Receipt</title>
        <style>
          body { font-family: Arial; font-size: 12px; padding: 10px; }
          h2, h3 { text-align: center; margin: 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          th, td { padding: 5px; text-align: left; }
          th { border-bottom: 1px solid #000; }
          tfoot td { border-top: 1px solid #000; font-weight: bold; }
          .total { text-align: right; }
        </style>
      </head>
      <body>
        <h2>Stock Manager Advance</h2>
        <h3>Order Receipt</h3>
        <p><strong>Customer:</strong> Walk-in Customer</p>
        <p><strong>Received By:</strong> Owner</p>
        <p><strong>Order Time:</strong> ${new Date().toLocaleString()}</p>

        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Item</th>
              <th>Qty</th>
              
              <th class="total">Amount</th>
            </tr>
          </thead>
          <tbody>
    `);

    products.forEach((p, i) => {
      orderWindow.document.write(`
        <tr>
          <td>${i + 1}</td>
          <td>${p.name}</td>
          <td>${p.qty} x ${p.price.toFixed(2)}</td>
          <td class="total">${p.lineTotal.toFixed(2)}</td>
        </tr>
      `);
    });

    orderWindow.document.write(`
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3">Total</td>
              <td class="total">${totalAmount.toFixed(2)}</td>
            </tr>
          </tfoot>
        </table>

        <p style="text-align:center;">Items: ${products.length} | Grand Total: ${totalAmount.toFixed(2)}</p>
        <p style="text-align:center;">Customer Copy</p>

        <script>
          window.print();
        <\/script>
      </body>
      </html>
    `);
    orderWindow.document.close();
  });
</script>


      <!-- 🟢 Payment Button -->
<button type="button" id="paymentBtn" class="btn btn-dark">
  <i class="fa fa-credit-card"></i> Payment
</button>

<!-- 💵 Payment Modal -->
<div id="paymentModal" class="pos-modal">
  <div class="pos-modal-header">
    <span>💵 Payment</span>
    <button id="closePayment" class="close-btn">&times;</button>
  </div>
  <div class="pos-modal-body">
    <div class="form-group">
      <label>Total Amount</label>
      <input type="text" id="totalAmount" class="form-control" readonly>
    </div>
    <div class="form-group">
      <label>Paid Amount</label>
      <input type="number" id="paidAmount" class="form-control">
    </div>
    <div class="form-group">
      <label>Balance</label>
      <input type="text" id="balanceAmount" class="form-control" readonly>
    </div>
    <div class="form-group">
      <label>Payment Method</label>
      <select id="paymentMethod" class="form-control">
        <option value="Cash">Cash</option>
        <option value="Card">Card</option>
        <option value="Bank Transfer">Bank Transfer</option>
      </select>
    </div>
    <div class="btn-group">
      <button id="confirmPayment" class="btn btn-success w-100">
        <i class="fa fa-check"></i> Confirm
      </button>
    </div>
  </div>
</div>

<!-- 🔲 Overlay -->
<div id="modalOverlay" class="modal-overlay"></div>
<style>
/* 🔲 Overlay */
.modal-overlay {
  display: none;
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.6);
  z-index: 9998;
}

/* 💵 Modal Container */
.pos-modal {
  display: none;
  position: fixed;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%) scale(0.95);
  background: #fff;
  width: 350px;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 0 25px rgba(0,0,0,0.4);
  z-index: 9999;
  animation: popup 0.3s ease forwards;
}

/* Header */
.pos-modal-header {
  background: #222;
  color: #fff;
  padding: 12px 15px;
  font-size: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pos-modal-header .close-btn {
  background: none;
  border: none;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
}

/* Body */
.pos-modal-body {
  padding: 15px;
}

.form-group {
  margin-bottom: 12px;
}

.form-group label {
  display: block;
  font-weight: bold;
  margin-bottom: 4px;
}

.form-group .form-control {
  width: 100%;
  padding: 6px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

/* Buttons */
.btn-group {
  margin-top: 10px;
}

.btn {
  display: inline-block;
  padding: 8px 12px;
  font-size: 14px;
  border-radius: 5px;
  cursor: pointer;
  border: none;
}

.btn-success {
  background: #28a745;
  color: #fff;
}

.btn-dark {
  background: #343a40;
  color: #fff;
}

.btn-success:hover {
  background: #218838;
}

/* Animation */
@keyframes popup {
  from { transform: translate(-50%, -50%) scale(0.7); opacity: 0; }
  to { transform: translate(-50%, -50%) scale(1); opacity: 1; }
}

</style>
<script>
  const paymentBtn = document.getElementById('paymentBtn');
  const paymentModal = document.getElementById('paymentModal');
  const modalOverlay = document.getElementById('modalOverlay');
  const totalAmountInput = document.getElementById('totalAmount');
  const paidAmountInput = document.getElementById('paidAmount');
  const balanceAmountInput = document.getElementById('balanceAmount');
  const closePayment = document.getElementById('closePayment');
  const confirmPayment = document.getElementById('confirmPayment');

  // 🧮 Open modal when Payment button clicked
  paymentBtn.addEventListener('click', () => {
    let total = 0;
    document.querySelectorAll('#selected_products tbody tr').forEach(row => {
      let price = parseFloat(row.querySelector('input[name="price[]"]').value);
      let qty = parseInt(row.querySelector('input[name="qty[]"]').value);
      total += price * qty;
    });

    totalAmountInput.value = total.toFixed(2);
    paidAmountInput.value = '';
    balanceAmountInput.value = '';
    paymentModal.style.display = 'block';
    modalOverlay.style.display = 'block';
  });

  // 💰 Update balance dynamically
  paidAmountInput.addEventListener('input', () => {
    const total = parseFloat(totalAmountInput.value);
    const paid = parseFloat(paidAmountInput.value) || 0;
    const balance = paid - total;
    balanceAmountInput.value = balance.toFixed(2);
  });

  // ❌ Close modal
  closePayment.addEventListener('click', () => {
    paymentModal.style.display = 'none';
    modalOverlay.style.display = 'none';
  });

  modalOverlay.addEventListener('click', () => {
    paymentModal.style.display = 'none';
    modalOverlay.style.display = 'none';
  });

  // ✅ Confirm payment
  confirmPayment.addEventListener('click', () => {
    const total = parseFloat(totalAmountInput.value);
    const paid = parseFloat(paidAmountInput.value) || 0;
    const balance = paid - total;
    const method = document.getElementById('paymentMethod').value;

    if (paid < total) {
      alert('⚠️ Paid amount is less than total!');
      return;
    }

    alert(`✅ Payment Successful\nTotal: ${total}\nPaid: ${paid}\nBalance: ${balance}\nMethod: ${method}`);

    paymentModal.style.display = 'none';
    modalOverlay.style.display = 'none';
  });
</script>

      
      <button type="button" class="btn btn-danger" onclick="confirmCancelAction()">Cancel</button>
    </div>
  </div>
</div>

<!-- Suspend Modal -->
<div id="suspendModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.4); z-index:1000;">
  <div style="background:#fff; width:400px; margin:120px auto; padding:20px; border-radius:5px; position:relative;">
    <h4>SUSPEND SALE</h4>
    <span onclick="closeSuspendModal()" style="position:absolute; right:10px; top:10px; cursor:pointer; font-size:20px;">&times;</span>
    <p>Please type reference note and submit to suspend this sale</p>
    <label for="suspendNote"><b>Reference Note</b></label>
    <input type="text" id="suspendNote" placeholder="Enter note here" style="width:100%; padding:8px; margin:10px 0;">
    <div style="text-align:right;">
      <button onclick="closeSuspendModal()" style="background:gray; color:white; padding:8px 12px; border:none; border-radius:4px;">Cancel</button>
      <button onclick="submitSuspend()" style="background:#007bff; color:white; padding:8px 12px; border:none; border-radius:4px;">Submit</button>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function openSuspendModal() { document.getElementById('suspendModal').style.display = 'block'; }
function closeSuspendModal() { document.getElementById('suspendModal').style.display = 'none'; document.getElementById('suspendNote').value = ''; }
function submitSuspend() {
  const note = document.getElementById('suspendNote').value.trim();
  if (note === '') { alert('⚠️ Please enter a reference note.'); return; }
  alert('✅ Sale suspended with note: ' + note);
  closeSuspendModal();
}
window.onclick = function(event) {
  const modal = document.getElementById('suspendModal');
  if (event.target === modal) { closeSuspendModal(); }
};

function confirmCancelAction() {
  Swal.fire({
    title: "Are you sure?",
    text: "This will cancel the current sale.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "OK",
    cancelButtonText: "Cancel",
    reverseButtons: true
  }).then((result) => {
    if (result.isConfirmed) {
      location.reload();
    }
  });
}
</script>

<script>
$(document).ready(function () {
  let orderTaxPercent = 0;
  let discountAmount = 0;

  // Search product
  $('#search_product').on('input', function () {
    let query = $(this).val();
    if (query.length > 1) {
      $.ajax({
        url: 'search_product.php',
        method: 'POST',
        data: { query: query },
        success: function (data) {
          $('#product_results').html(data).show();
        }
      });
    } else {
      $('#product_results').hide();
    }
  });

  $(document).on('click', '.search-item', function () {
    let id = $(this).data('id');
    let name = $(this).data('name');
    let price = parseFloat($(this).data('price')) || 0;
    addProductRow(id, name, price);
    $('#product_results').hide();
    $('#search_product').val('');
  });

  function addProductRow(id, name, price) {
    let exists = false;
    $('#selected_products tbody tr').each(function () {
      let pid = $(this).find('input[name="product_id[]"]').val();
      if (pid == id) { exists = true; }
    });
    if (exists) return;

    let row = `<tr>
      <td>${name}<input type="hidden" name="product_id[]" value="${id}"></td>
      <td><span class="price">${price.toFixed(2)}</span><input type="hidden" name="price[]" value="${price.toFixed(2)}"></td>
      <td><input type="number" name="qty[]" value="1" min="1" class="form-control qty" style="width:80px; text-align:center;"></td>
      <td class="subtotal">${price.toFixed(2)}</td>
      <td><button type="button" class="btn btn-danger btn-sm remove"><i class="fa fa-trash"></i></button></td>
    </tr>`;
    $('#selected_products tbody').append(row);
    updateTotalsAndSummary();
  }

  $(document).on('input', '.qty', function () {
    let row = $(this).closest('tr');
    let price = parseFloat(row.find('input[name="price[]"]').val()) || 0;
    let qty = parseFloat($(this).val()) || 0;
    let subtotal = price * qty;
    row.find('.subtotal').text(subtotal.toFixed(2));
    updateTotalsAndSummary();
  });

  $(document).on('click', '.remove', function () {
    $(this).closest('tr').remove();
    updateTotalsAndSummary();
  });

  function updateTotalsAndSummary() {
    let total = 0;
    let itemCount = 0;
    let qtyCount = 0;

    $('#selected_products tbody tr').each(function () {
      let subtotal = parseFloat($(this).find('.subtotal').text()) || 0;
      let qty = parseFloat($(this).find('input[name="qty[]"]').val()) || 0;
      total += subtotal;
      qtyCount += qty;
      itemCount++;
    });

    let taxAmount = total * (orderTaxPercent / 100);
    let finalTotal = total + taxAmount - discountAmount;
    if (finalTotal < 0) finalTotal = 0;

    $('#total_amount').val(finalTotal.toFixed(2));
    $('#summary_items').text(itemCount + ' (' + qtyCount + ')');
    $('#summary_total').text('₨ ' + total.toFixed(2));
    $('#summary_tax_display').text('₨ ' + taxAmount.toFixed(2));
    $('#summary_discount_display').text('₨ ' + discountAmount.toFixed(2));
    $('#total_payable').text(finalTotal.toFixed(2));
  }

  $('#edit_tax').on('click', function (e) {
    e.stopPropagation();
    $('#tax_form').toggle();
    $('#order_tax').val(orderTaxPercent);
  });
  $('#save_tax').on('click', function (e) {
    e.stopPropagation();
    orderTaxPercent = parseFloat($('#order_tax').val()) || 0;
    $('#tax_form').hide();
    updateTotalsAndSummary();
  });

  $('#edit_discount').on('click', function (e) {
    e.stopPropagation();
    $('#discount_form').toggle();
    $('#discount_input').val(discountAmount);
  });
  $('#save_discount').on('click', function (e) {
    e.stopPropagation();
    discountAmount = parseFloat($('#discount_input').val()) || 0;
    $('#discount_form').hide();
    updateTotalsAndSummary();
  });

  $(document).on('click', function (e) {
    if (!$(e.target).closest('#tax_form, #edit_tax').length) $('#tax_form').hide();
    if (!$(e.target).closest('#discount_form, #edit_discount').length) $('#discount_form').hide();
  });

  updateTotalsAndSummary();
});


</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Bootstrap JS (required for modals to work) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function(){

    // Search customers as you type
    $('#walkin_customer_search').keyup(function(){
        let query = $(this).val();
        if(query != ''){
            $.ajax({
                url: "search_customer.php",
                method: "POST",
                data: {query: query},
                success: function(data){
                    $('#customer_suggestions').show();
                    $('#customer_suggestions').html(data);
                }
            });
        } else {
            $('#customer_suggestions').hide();
        }
    });

    // Select a customer from suggestions
    $(document).on('click', '#customer_suggestions li', function(){
        let name = $(this).text();
        let id = $(this).data('id');
        $('#walkin_customer_search').val(name);
        $('#customer_id').val(id);
        $('#customer_suggestions').hide();
    });

    // Edit button - fetch and show customer details
    $('#editCustomerBtn').click(function(){
        let id = $('#customer_id').val();
        if(id){
            $.ajax({
                url: "fetch_customer_details.php",
                method: "POST",
                data: {customer_id: id},
                success: function(data){
                    $('#customer_details').html(data);
                    $('#customerModal').modal('show');
                }
            });
        } else {
            alert('Please select a customer first.');
        }
    });

});
</script>

<script>
$(document).ready(function() {
  // When a customer is clicked from search results
  $(document).on('click', '.customer-item', function(e) {
    e.preventDefault();
    const id = $(this).data('id');
    const name = $(this).data('name');

    $('#customer_id').val(id);
    $('#walkin_customer_search').val(name);
    $('#customer_suggestions').hide();
  });

  // When View Customer button clicked (Eye button)
  $('#viewCustomerBtn').on('click', function() {
    const customerId = $('#customer_id').val();
    if (!customerId || customerId === '0') {
      alert('Please select a customer first!');
      return;
    }

    $.ajax({
      url: 'get_customer_details.php',
      method: 'GET',
      data: { id: customerId },
      dataType: 'json',
      success: function(res) {
        if (res.status === 'success') {
          $('#c_name').text(res.name || 'N/A');
          $('#c_email').text(res.email || 'N/A');
          $('#c_phone').text(res.phone || 'N/A');
          $('#c_address').text(res.address || 'N/A');
          $('#customerModal').modal('show');
        } else {
          alert('Customer not found');
        }
      },
      error: function() {
        alert('Error fetching customer details.');
      }
    });
  });

  // Print button (keeps your existing functionality)
  $('#printCustomer').click(function() {
    const printContents = document.getElementById('customerInfo').innerHTML;
    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write('<html><head><title>Customer Info</title>');
    printWindow.document.write('<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h3 style="text-align:center;">Customer Information</h3>');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
  });
});
</script>

</body>
</html>
